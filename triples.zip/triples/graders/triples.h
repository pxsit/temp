#include <vector>

long long count_triples(std::vector<int> H);

std::vector<int> construct_range(int M, int K);
