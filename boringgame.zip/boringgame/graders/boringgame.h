long long play_game();

bool ask(long long x);
