#include "testlib.h"
#include <cstdio>
#include <csignal>
#include <string>

using namespace std;

/******************************** Begin testlib-related material ********************************/

inline FILE* openFile(const char* name, const char* mode) {
	FILE* file = fopen(name, mode);
	if (!file)
		quitf(_fail, "Could not open file '%s' with mode '%s'.", name, mode);
	closeOnHalt(file);
	return file;
}


vector<FILE*> mgr2sol, sol2mgr;
FILE* log_file = nullptr;

void nullifyFile(int idx) {
	mgr2sol[idx] = sol2mgr[idx] = nullptr;
}

#ifdef __GNUC__
__attribute__ ((format (printf, 1, 2)))
#endif
void log_printf(const char* fmt, ...) {
	if (log_file) {
		FMT_TO_RESULT(fmt, fmt, message);
		fprintf(log_file, "%s", message.c_str());
		fflush(log_file);
	}
}

void registerManager(std::string probName, int num_processes, int argc, char* argv[]) {
	setName("manager for problem %s", probName.c_str());
	__testlib_ensuresPreconditions();
	testlibMode = _checker;
	random_t::version = 1; // Random generator version
	__testlib_set_binary(stdin);
	ouf.mode = _output;

	{//Keep alive on broken pipes
		//signal(SIGPIPE, SIG_IGN);
		struct sigaction sa;
		sa.sa_handler = SIG_IGN;
		sigaction(SIGPIPE, &sa, NULL);
	}

	int required_args = 1 + 2 * num_processes;
	if (argc < required_args || required_args+1 < argc) {
		string usage = format("'%s'", argv[0]);
		for (int i = 0; i < num_processes; i++)
			usage += format(" sol%d-to-mgr mgr-to-sol%d", i, i);
		usage += " [mgr_log] < input-file";
		quitf(_fail,
			"Manager for problem %s:\n"
			"Invalid number of arguments: %d\n"
			"Usage: %s",
			probName.c_str(), argc-1, usage.c_str());
	}

	inf.init(stdin, _input);
	closeOnHalt(stdout);
	closeOnHalt(stderr);

	mgr2sol.resize(num_processes);
	sol2mgr.resize(num_processes);
	for (int i = 0; i < num_processes; i++) {
		mgr2sol[i] = openFile(argv[1 + 2*i + 1], "a");
		sol2mgr[i] = openFile(argv[1 + 2*i + 0], "r");
	}

	if (argc > required_args) {
		log_file = openFile(argv[required_args], "w");
	} else {
		log_file = nullptr;
	}
}
/********************************* End testlib-related material *********************************/


// utils

#define rep(i, n) for(int i = 0, i##__n = (int)(n); i < i##__n; ++i)

template<class C> int sz(const C& c) { return std::size(c); }

using LL = long long;

template<class T> constexpr T div_ceil(T a, T b) { return (a+b-1) / b; }

void set_vi_bit(vector<int> &v, int i, int b) {
	int& x = v[i/32];
	int j = i%32;
	if (b == 1)
		x |= (1 << j);
	else
		x &= ~(1 << j);
}


#define log_var(var_name) log_printf("%s = %s\n", #var_name, toString(var_name).c_str());

template<class C>
void log_array(const C& c, string delim=" ", string ending="\n") {
	string d = "";
	for (const auto& x : c) {
		log_printf("%s%s", d.c_str(), toString(x).c_str());
		d = delim;
	}
	log_printf("%s", ending.c_str());
}

// grader/manager protocol

const int secret_g2m = 0x1379F230;
const int secret_m2g = 0x61234FC0;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__OK_NEW_GAME = 1;
const int M2G_CODE__OK_END_OF_GAMES = 2;
const int M2G_CODE__DIE = 3;

const int G2M_CODE__OK_NEW_QUESTION = 0;
const int G2M_CODE__OK_GUESS_ANSWER = 1;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


int fifo_idx = 0;

enum class ActionMode {
	ok_new_question,
	ok_guess_answer,
} ok_action_mode;

void out_flush() {
	fflush(mgr2sol[fifo_idx]);
}

void write_int(int x) {
	if(1 != fwrite(&x, sizeof(x), 1, mgr2sol[fifo_idx])) {
		nullifyFile(fifo_idx);
		// add logging here
	}
}

void write_ll(LL x) {
	if(1 != fwrite(&x, sizeof(x), 1, mgr2sol[fifo_idx])) {
		nullifyFile(fifo_idx);
		// add logging here
	}
}

void write_int_vector(const vector<int>& arr) {
	int len = (int)sz(arr);
	if(len != (int)fwrite(arr.data(), sizeof(int), len, mgr2sol[fifo_idx])) {
		nullifyFile(fifo_idx);
		// add logging here
	}
}

void write_secret(int m2g_code = M2G_CODE__OK) {
	write_int(secret_m2g | m2g_code);
}

#ifdef __GNUC__
__attribute__ ((format (printf, 2, 3)))
#endif
NORETURN void die(TResult result, const char* format, ...) {
	FMT_TO_RESULT(format, format, message);
	log_printf("Dying with message '%s'\n", message.c_str());
	rep(i, sz(mgr2sol))
		if(mgr2sol[i] != nullptr) {
			fifo_idx = i;
			log_printf("Sending secret with code DIE to mgr2sol[%d]\n", fifo_idx);
			write_secret(M2G_CODE__DIE);
			out_flush();
		}
	log_printf("Quitting with result code %d\n", int(result));
	quit(result, message);
}

NORETURN void die_invalid_argument(const string &msg) {
	RESULT_MESSAGE_WRONG += ": Invalid argument";
	die(_wa, "%s", msg.c_str());
}

NORETURN void die_too_many_calls(const string &msg) {
	RESULT_MESSAGE_WRONG += ": Too many calls";
	die(_wa, "%s", msg.c_str());
}

int read_int() {
	int x;
	if(1 != fread(&x, sizeof(x), 1, sol2mgr[fifo_idx])) {
		nullifyFile(fifo_idx);
		die(_fail, "Could not read int from sol2mgr[%d]", fifo_idx);
	}
	return x;
}

LL read_ll() {
	LL x;
	if(1 != fread(&x, sizeof(x), 1, sol2mgr[fifo_idx])) {
		nullifyFile(fifo_idx);
		die(_fail, "Could not read ll from sol2mgr[%d]", fifo_idx);
	}
	return x;
}

void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_g2m)
		die(_pv, "Possible tampering with sol2mgr[%d]", fifo_idx);
	int g2m_code = secret & code_mask;
	switch (g2m_code) {
		case G2M_CODE__OK_NEW_QUESTION:
			ok_action_mode = ActionMode::ok_new_question;
			return;
		case G2M_CODE__OK_GUESS_ANSWER:
			ok_action_mode = ActionMode::ok_guess_answer;
			return;
		case G2M_CODE__SILENT:
			die(_fail, "Unexpected g2m_code SILENT from sol2mgr[%d]", fifo_idx);
		case G2M_CODE__TAMPER_M2G:
			die(_pv, "Possible tampering with mgr2sol[%d]", fifo_idx);
		case G2M_CODE__PV_CALL_EXIT:
			die(_pv, "Solution[%d] called exit()", fifo_idx);
		default:
			die(_fail, "Unknown g2m_code %d from sol2mgr[%d]", g2m_code, fifo_idx);
	}
}


// problem logic

int maxInd=0;

const int LIMQ=150;
const long long MAXGUESS=1'000'000'000'000'000'000LL;
const int IND_CUTOFF[]={150, 132, 78, 72, 67};
const double POINTS[]={0.0, 0.20, 0.20, 0.30, 0.30};

void AC() {
	if (maxInd <= 67)
		quitf(_ok, "Success, optimal strategy");
    double pts=0.0;
    for(int j=0;j<5;++j){
        if(maxInd<=IND_CUTOFF[j]) {
            pts+=POINTS[j];
        }else {
            double len=IND_CUTOFF[j-1]-IND_CUTOFF[j];
            double diff=IND_CUTOFF[j-1]-maxInd;
            pts+=POINTS[j]*pow(diff/len, 2);
            break ;
        }
    }
    quitp(pts, "Success");
}

struct Response {
    long long guess;
    long long resp;
};

vector<pair<long long, long long>> intervalUnion(vector<pair<long long, long long>> ivs) {
    sort(ivs.begin(), ivs.end());
    decltype(ivs) realIvs;
    for(auto i:ivs) {
        if(realIvs.empty() || realIvs.back().second<i.first) {
            realIvs.push_back(i);
        }else {
            realIvs.back().second=max(realIvs.back().second, i.second);
        }
    }
    return realIvs;
}

long long intervalLengthSum(vector<pair<long long, long long>>& ivs) {
    long long ans=0;
    for(auto i:ivs) {
        ans+=i.second-i.first+1;
    }
    return ans;
}


__int128 validStrategies(vector<Response>& history, long long maxq, bool debug=false) {
    if(history.empty()) return 0;
    __int128 ans = 0;
    for(int lieAfter=1;lieAfter<=min((int)history.size(), (int)maxq);++lieAfter) {
        long long L=1, R=MAXGUESS;
        for(int j=0;j<(int)history.size();++j) {
            int lie = j>=lieAfter;
            if(history[j].resp^lie) {
                L=max(L, history[j].guess);
            }else {
                R=min(R, history[j].guess-1);
            }
        }
        if(L<=R) {
            __int128 coeff=1;
            if(lieAfter>=history.size()) {
                coeff=maxq-lieAfter+1;
            }
            ans+=(coeff*(R-L+1));
        }
    }        
   
    
    return ans;
}

vector<pair<long long, long long>> getValidIvs(vector<Response>& history)  {
    vector<pair<long long, long long>> ivs;
    if(history.empty()) return {{1, MAXGUESS}};
    for(int lieAfter=1;lieAfter<=history.size();++lieAfter) {
        long long L=1, R=MAXGUESS;
        for(int j=0;j<(int)history.size();++j) {
            int lie = j>=lieAfter;
            if(history[j].resp^lie) {
                L=max(L, history[j].guess);
            }else {
                R=min(R, history[j].guess-1);
            }
        }
        if(L<=R) ivs.push_back({L,R});
    }
    return intervalUnion(ivs);
}

long long validCount(vector<Response>& history) {
    auto realIvs = getValidIvs(history);
    long long ans=0;
    for(auto i:realIvs) {
        ans+=i.second-i.first+1;
    }
    return ans;
}

void interactor(vector<Response>& history, function<bool(long long, int)> handleGuess, function<bool(long long)> handleAnswer) {
	
	write_secret(M2G_CODE__OK_NEW_GAME);
	out_flush();

    int ind = 0;

    while(1) {	
        read_secret();
        if(ok_action_mode==ActionMode::ok_new_question) {
            if(ind>=LIMQ) {
                die_too_many_calls("Too many calls");
            }

            long long guess = read_ll();
            if(!(1<=guess && guess<=MAXGUESS)) {
                die_invalid_argument("Invalid argument");
            }

            bool response=handleGuess(guess, ind);
            history.push_back({guess, response});
			ind++;

			write_secret(M2G_CODE__OK);
            write_int(response ? 1 : 0);
			out_flush();

        }else if(ok_action_mode == ActionMode::ok_guess_answer) {

            long long guess = read_ll();

            if(!handleAnswer(guess)) {
                die(_wa, "Guessed the number incorrectly");
            } else {
                maxInd = max(maxInd, ind);
                return;
            }
        }else {
            die(_fail, "Invalid action mode");
        }
    }
}

int main(int argc, char **argv) {
    registerManager("boringgame", 1, argc, argv);
    
    int T = inf.readInt();
	log_printf("Found %d testcases\n", T);

    for(int t=0;t<T;++t) {
        string mode = inf.readToken();
		log_printf("Starting interactor in mode: %s\n", mode.c_str());
        if(mode=="non-adaptive") {
            long long secret = inf.readLong(), lie_after = inf.readLong();
			log_printf("S=%lld; K=%lld\n", secret, lie_after);
            vector<Response> history;
            interactor(history, [&secret, &lie_after](long long guess, int ind) -> bool {
                return (guess<=secret)^(lie_after<=ind);
            }, [&secret, &history](long long answer) -> bool {
                return secret==answer && validCount(history)==1;
            });
        }else if(mode=="adaptive"){
            long long maxq = inf.readLong();
			log_printf("maxq=%lld\n", maxq);
            vector<Response> history;
            interactor(history, [&history, &maxq, &t](long long guess, int ind) -> bool {
                history.push_back({guess, 0});
                __int128 if0 = validStrategies(history, maxq);
                history.pop_back();
                
                history.push_back({guess, 1});
                __int128 if1 = validStrategies(history, maxq);
                history.pop_back();
                if(if0<if1) return 1;
                else if(if0>if1) return 0;
                return rnd.next(0, 1);
            }, [&history](long long answer) -> bool {
                auto ivs = getValidIvs(history);
                if(ivs.empty()) return false;
                long long len = 0;
                for(auto i:ivs) len+=i.second-i.first+1;
                return len==1 && ivs.front().first==answer; 
            });
        }else {
            die(_fail, "Unknown manager input");
        }
    }

	write_secret(M2G_CODE__OK_END_OF_GAMES);
	out_flush();

    AC();

    return 0;
}
