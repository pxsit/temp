#include "boringgame.h"
#include <cstdio>
#include <cstdlib>
#include <csignal>
#include <iostream>

using namespace std;


namespace {

/******************************** Begin testlib-related material ********************************/
#ifdef _MSC_VER
#   define NORETURN __declspec(noreturn)
#elif defined __GNUC__
#   define NORETURN __attribute__ ((noreturn))
#else
#   define NORETURN
#endif
/********************************* End testlib-related material *********************************/


// utils

using LL = long long;


// grader/manager protocol

const int secret_g2m = 0x1379F230;
const int secret_m2g = 0x61234FC0;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__OK_NEW_GAME = 1;
const int M2G_CODE__OK_END_OF_GAMES = 2;

const int G2M_CODE__OK_NEW_QUESTION = 0;
const int G2M_CODE__OK_GUESS_ANSWER = 1;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


bool exit_allowed = false;

NORETURN void authorized_exit(int exit_code) {
  exit_allowed = true;
  exit(exit_code);
}


FILE* fin = stdin;
FILE* fout = stdout;

void out_flush() {
	fflush(fout);
}

void write_int(int x) {
	if(1 != fwrite(&x, sizeof(x), 1, fout)) {
		fprintf(stderr, "Could not write int to fout\n");
		authorized_exit(3);
	}
}

void write_ll(LL x) {
	if(1 != fwrite(&x, sizeof(x), 1, fout)) {
		fprintf(stderr, "Could not write ll to fout\n");
		authorized_exit(3);
	}
}

void write_secret(int g2m_code) {
	write_int(secret_g2m | g2m_code);
}

NORETURN void die(int g2m_code) {
	if(g2m_code == G2M_CODE__OK_NEW_QUESTION || g2m_code == G2M_CODE__OK_GUESS_ANSWER) {
		fprintf(stderr, "Shall not die with code OK\n");
		authorized_exit(5);
	}
	fprintf(stderr, "Dying with code %d\n", g2m_code);
	if(g2m_code != G2M_CODE__SILENT)
		write_secret(g2m_code);
	fclose(fin);
	fclose(fout);
	authorized_exit(0);
}

int read_int() {
	int x;
	if(1 != fread(&x, sizeof(x), 1, fin)) {
		fprintf(stderr, "Could not read int from fin\n");
		authorized_exit(3);
	}
	return x;
}

LL read_ll() {
	LL x;
	if(1 != fread(&x, sizeof(x), 1, fin)) {
		fprintf(stderr, "Could not read ll from fin\n");
		authorized_exit(3);
	}
	return x;
}

void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_m2g)
		die(G2M_CODE__TAMPER_M2G);
	int m2g_code = secret & code_mask;
	if(m2g_code != M2G_CODE__OK && m2g_code != M2G_CODE__OK_NEW_GAME && m2g_code != M2G_CODE__OK_END_OF_GAMES)
		die(G2M_CODE__SILENT);
	if (m2g_code == M2G_CODE__OK_END_OF_GAMES)
		authorized_exit(0);
}

void check_exit_protocol() {
  if (!exit_allowed)
    die(G2M_CODE__PV_CALL_EXIT);
}

} // namespace


bool ask(long long x) {
	write_secret(G2M_CODE__OK_NEW_QUESTION);
	write_ll(x);
	out_flush();

	read_secret();
	int ans = read_int();

	if (ans == 0)
		return false;
	else if (ans == 1)
		return true;
	else
		die(G2M_CODE__TAMPER_M2G);
}

int main() {
	signal(SIGPIPE, SIG_IGN);
	atexit(check_exit_protocol);
	at_quick_exit(check_exit_protocol);

	while (true) {
		read_secret();

		LL guess = play_game();

		write_secret(G2M_CODE__OK_GUESS_ANSWER);
		write_ll(guess);
		out_flush();
	}
	
	die(G2M_CODE__SILENT); // reached unreachable code
}
