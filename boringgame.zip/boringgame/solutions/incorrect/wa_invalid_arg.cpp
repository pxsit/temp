#include "boringgame.h"

long long play_game() {
    ask(0);
    return 1;
}
