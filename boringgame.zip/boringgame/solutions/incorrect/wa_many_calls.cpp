#include "boringgame.h"

long long play_game() {
    while (true)
        ask(1);
    return 1;
}
