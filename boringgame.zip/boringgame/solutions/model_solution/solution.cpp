#include "boringgame.h"

#include <vector>
#include <utility>
#include <cassert>

using namespace std;
using ll = long long;

const int K=67;

struct Response {
    ll guess;
    ll resp;
};

vector<pair<ll, ll>> calcIntervals(vector<Response>& history) {
    vector<pair<ll,ll>> res(K+1, make_pair(1LL, (ll)1e18));
    for(int lieAfter=1;lieAfter<=K;++lieAfter) {
        ll& L=res[lieAfter].first;
        ll& R=res[lieAfter].second;
        for(int j=0;j<(int)history.size();++j) {
            int lie = j>=lieAfter;
            if(history[j].resp^lie) {
                L=max(L, history[j].guess);
            }else {
                R=min(R, history[j].guess-1);
            }
        }
    }
    return res;
}

__int128 getHypothetical(vector<pair<ll,ll>>& ivs, int ind, ll x, ll resp) {
    __int128 res=0;
    for(int lieAfter=1;lieAfter<=K;++lieAfter) {
        ll L=ivs[lieAfter].first, R=ivs[lieAfter].second;
        int lie = ind>=lieAfter;
        if(resp^lie) {
            L=max(L, x);
        }else {
            R=min(R, x-1);
        }
        if(L<=R) res+=R-L+1;
    }
    return res;
}

ll deduce(vector<Response>& history) {
    ll ans=-1;
    for(int lieAfter=1;lieAfter<=history.size();++lieAfter) {
        long long L=1, R=ll(1e18);
        for(int j=0;j<(int)history.size();++j) {
            int lie = j>=lieAfter;
            if(history[j].resp^lie) {
                L=max(L, history[j].guess);
            }else {
                R=min(R, history[j].guess-1);
            }
        }
        if(L<=R) {
            assert(L==R);
            assert(ans==-1);
            ans=L;
        }
    }        
    assert(ans!=-1);
    return ans;
}

ll calc(vector<Response>& history) {
    ll L=1, R=ll(1e18)+1;
    auto ivs = calcIntervals(history);
    auto f=[&](ll x) -> __int128 {
        __int128 egyik = getHypothetical(ivs, history.size(), x, 0);
        __int128 masik = getHypothetical(ivs, history.size(), x, 1);
        return egyik-masik;
    };

    __int128 dR = f(R);
    while(L+1<R) {
        ll mid=(L+R)/2;
        auto val = f(mid);
        if((val>0 && dR>0) || (val<0 && dR<0)) {
            R=mid;
        }else {
            L=mid;
        }
    }
    return L;
}

ll search() {
    vector<Response> history;
    for(int i=0;i<K;++i) {
        ll to_ask = calc(history);
        history.push_back({to_ask, ask(to_ask)});
    }
    return deduce(history);
}

long long play_game() {
    return search();
}
