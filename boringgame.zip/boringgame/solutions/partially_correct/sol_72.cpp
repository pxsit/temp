#include "boringgame.h"
#include <vector>
#include <utility>
#include <iostream>

using namespace std;
using ll = long long ;

ll search() {
    int magic=11;

    int x=0;
    ll L=1, R=ll(1e18)+1;
    vector<pair<ll,ll>> hist;
    
    while(L+1<R) {
        hist.push_back({L,R});
        ll mid=(L+R)/2;
        bool res=ask(mid);
        
        if(res^x) {
            L=mid;
        }else {
            R=mid;
        }

        if(0==x && (hist.size()==magic || L+1>=R)) {
            magic--;
            if(!ask(1)) {
                x=1;
                L=hist.front().first;
                R=hist.front().second;
                hist.clear();
            }else {
                hist.clear();
            }
        }

    }
    return L;
}


long long play_game() {
    return search();
}
