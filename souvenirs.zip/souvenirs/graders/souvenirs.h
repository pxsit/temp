#include <utility>
#include <vector>

void buy_souvenirs(int N, long long P0);

std::pair<std::vector<int>, long long> transaction(long long M);
