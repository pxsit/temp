#include "souvenirs.h"

void buy_souvenirs(int N, long long P0) {
  N = N;
  for (int i = 0; i < 5000; i++)
    transaction(P0 - 1);
}
