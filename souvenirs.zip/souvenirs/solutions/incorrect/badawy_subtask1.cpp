#include<bits/stdc++.h>
#include "souvenirs.h"

using namespace std;

void buy_souvenirs(int N, long long P0)
{
    N=N;
    transaction(P0-1);
}