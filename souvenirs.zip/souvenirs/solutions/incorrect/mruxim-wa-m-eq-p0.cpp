#include "souvenirs.h"

void buy_souvenirs(int N, long long P0) {
	N=N; P0=P0;
	transaction(P0);
}
