#include "testlib.h"
#include <string>
#include <vector>
#include <set>

const std::string input_secret = "IOCLjM9howbeoZ4Sq2hWHTLKMdWP6cpn";
const std::string output_secret = "Qnhk58w9iSUhiuKYIX4ySfywaXRcHc70";

int count(const std::string& S) {
    std::set<std::string> found;
    int ans = 0;
    int L = S.length();
    
    for (int i = 0; i < L; ++i) {
        int j = 1;
        while (i + 2 * j <= L) {
            std::string u = S.substr(i, j);
            std::string v = S.substr(i + j, j);
            if (u == v && !found.count(u)) {
                found.insert(u);
                ++ans;
            }
            ++j;
        }
    }
    return ans;
}

void checkPart1() {
    readBothSecrets(output_secret);
    readBothGraderResults();
    
    compareRemainingLines(1);
}

void checkPart2() {
	const int N = 100;
	std::string type = inf.readToken("weakest|strongest");
	inf.readEoln();

	std::string S = ouf.readToken();
	if (!ouf.seekEof() || S.length() != N)
		quitf(_wa, "not eof / incorrect length");
	for (char c : S)
		if (c != '0' && c != '1')
			quitf(_wa, "not a binary string");

	int cnt = count(S);

	if (type == "weakest") {
        if (cnt > 20)
            quitf(_wa, "wrong answer, strength: %d", cnt);
        else if (cnt >= 5)
            quitp((21.0 - cnt) / 25.0, "partially correct, strength: %d", cnt);
        else if (cnt == 4)
            quitp(20.0 / 25.0, "partially correct, strength: %d", cnt);
        else
            quitf(_ok, "correct, strength: %d", cnt);
    }
    else if (type == "strongest") {
        if (cnt <= 50)
            quitf(_wa, "wrong answer, strength: %d", cnt);
        else if (cnt <= 80)
            quitp((cnt - 50.0) / 60.0, "partially correct, strength: %d", cnt);
        else if (cnt == 81)
            quitp(35.0 / 60.0, "partially correct, strength: %d", cnt);
        else if (cnt == 82)
            quitp(40.0 / 60.0, "partially correct, strength: %d", cnt);
        else if (cnt == 83)
            quitp(45.0 / 60.0, "partially correct, strength: %d", cnt);
        else
            quitf(_ok, "correct, strength: %d", cnt);
    }
}

int main(int argc, char *argv[]) {
    registerChecker("bitstrings", 4, argv);

    inf.readToken(input_secret);
    inf.readEoln();

    int part = inf.readInt();
    inf.readEoln();

    if (part == 1) {
        checkPart1();
    }
    else {
        checkPart2();
    }
}
