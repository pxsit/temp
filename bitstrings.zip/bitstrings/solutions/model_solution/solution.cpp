#include "bitstrings.h"
#include <set>
#include <iostream>

using namespace std;
using lll = __int128_t;
const int L = 100, MAXD = 3, MAXG = 3, MAXM = 16;
set<lll> found, nw[L];
string sol = "";

int count_duplicated(string S) {
    set<string> has;
    int ans = 0;
    int len = S.length();
    
    for (int i = 0; i < len; ++i) {
        int j = 1;
        while (i + 2 * j <= len) {
            string u = S.substr(i, j);
            string v = S.substr(i + j, j);
            if (u == v && !has.count(u)) {
                has.insert(u);
                ++ans;
            }
            ++j;
        }
    }
    return ans;
}

void save(int sz, lll ans) {
    for (int j = L - 1; j >= 0; --j)
        sol += ((ans & (lll(1)<<j)) ? "1" : "0");
    cerr << sz << " " << sol << endl;
	for (int j = 0; j < L; ++j)
        cerr << nw[j].size() << " ";
    cerr << endl;
}

void count(lll x, int pos) {
    set<lll>& cnw = nw[pos];
    cnw.clear();
    int len = pos + 1;
    for (lll j = 1; 2 * j <= len; ++j) {
        lll u = ((lll(1) << len) - 1) & x;
        u >>= len - j;
        u |= j << 60;
        lll v = ((lll(1) << (len - j)) - 1) & x;
        v >>= len - 2 * j;
        v |= j << 60;
        if (u == v && found.count(u) == 0 && cnw.count(u) == 0) {
            cnw.insert(u);
        }
    }
}

bool rec_w(lll cur = 0, int pos = 1) {
    if (pos == L) {
        save(found.size(), cur);
        return true;
    }

    for (lll i = 0; i <= 1; ++i) {
        cur |= (i << pos);
        count(cur, pos);
        if (nw[pos].size() > 0) {
            for (auto& fx : nw[pos])
                found.insert(fx);
            if (found.size() <= 3 && rec_w(cur, pos + 1))
				return true;
            for (auto& fx : nw[pos])
                found.erase(fx);
        }
        else if (rec_w(cur, pos + 1))
			return true;
    }
	return false;
}

string find_weakest() {
	rec_w();
	return sol;
}

bool rec(lll cur = 0, int pos = 1, int misscnt = 1, int grace = MAXG) {
    if (pos == L) {
        if ((int)found.size() >= 84) {
            save(found.size(), cur);
			return true;
        }
        return false;
    }

    for (lll i = 0; i <= 1; ++i) {
        cur |= (i << pos);
        count(cur, pos);
        if (nw[pos].size() > 0) {
            for (auto& fx : nw[pos])
                found.insert(fx);
            if (rec(cur, pos + 1, misscnt, MAXG))
				return true;
            for (auto& fx : nw[pos])
                found.erase(fx);
        }
        else if (misscnt < MAXM && grace > 0)
            if (rec(cur, pos + 1, misscnt + 1, grace - 1))
				return true;
    }
	return false;
}

string find_strongest() {
	rec();
	return sol;
}
