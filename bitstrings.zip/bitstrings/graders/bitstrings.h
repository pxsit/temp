#include <string>

int count_duplicated(std::string S);

std::string find_weakest();

std::string find_strongest();
