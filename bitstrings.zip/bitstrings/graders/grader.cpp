#include "bitstrings.h"
#include <cassert>
#include <cstdio>
#include <string>

namespace {
// BEGIN SECRET
const std::string input_secret = "IOCLjM9howbeoZ4Sq2hWHTLKMdWP6cpn";
const std::string output_secret = "Qnhk58w9iSUhiuKYIX4ySfywaXRcHc70";
// END SECRET

void run_part1() {
  char tmp[101];
  assert(1 == scanf("%100s", tmp));
  std::string S = tmp;
  fclose(stdin);

  int K = count_duplicated(S);

  // BEGIN SECRET
  printf("%s\n", output_secret.c_str());
  printf("OK\n");
  // END SECRET
  printf("%d\n", K);
  fclose(stdout);
}

void run_part2() {
  char tmp[101];
  assert(1 == scanf("%100s", tmp));
  std::string T = tmp;
  fclose(stdin);

  std::string S;
  if (T == "weakest")
    S = find_weakest();
  else if (T == "strongest")
    S = find_strongest();
  // BEGIN SECRET
  else {
    printf("%s\n", output_secret.c_str());
    printf("PV\n");
    printf("Possible tampering with the input\n");
    fclose(stdout);
    exit(0);
  }
  // END SECRET

  printf("%s\n", S.c_str());

  fclose(stdout);
}

} // namespace

int main() {
  // BEGIN SECRET
  char secret[1000];
  assert(1 == scanf("%999s", secret));
  if (std::string(secret) != input_secret) {
    printf("%s\n", output_secret.c_str());
    printf("PV\n");
    printf("Possible tampering with the input\n");
    fclose(stdout);
    return 0;
  }
  // END SECRET
  int part;
  assert(1 == scanf("%d", &part));
  if (part == 1)
    run_part1();
  else if (part == 2)
    run_part2();
  // BEGIN SECRET
  else {
    printf("%s\n", output_secret.c_str());
    printf("PV\n");
    printf("Possible tampering with the input\n");
    fclose(stdout);
    return 0;
  }
  // END SECRET

  return 0;
}
