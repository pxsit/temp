#include <vector>

std::vector<int> Alicia(std::vector<int> P);

std::vector<int> Beatriz(std ::vector<int> Q);
