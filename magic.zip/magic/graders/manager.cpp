#include "testlib.h"
#include <csignal>
#include <random>
#include <vector>
#include <algorithm>

using namespace std;


/******************************** Begin testlib-related material ********************************/

inline FILE* openFile(const char* name, const char* mode) {
	FILE* file = fopen(name, mode);
	if (!file)
		quitf(_fail, "Could not open file '%s' with mode '%s'.", name, mode);
	closeOnHalt(file);
	return file;
}


vector<FILE*> mgr2sol, sol2mgr;
FILE* log_file = nullptr;

void nullifyFile(int idx) {
	mgr2sol[idx] = sol2mgr[idx] = nullptr;
}

#ifdef __GNUC__
__attribute__ ((format (printf, 1, 2)))
#endif
void log_printf(const char* fmt, ...) {
	if (log_file) {
		FMT_TO_RESULT(fmt, fmt, message);
		fprintf(log_file, "%s", message.c_str());
		fflush(log_file);
	}
}

void registerManager(std::string probName, int num_processes, int argc, char* argv[]) {
	setName("manager for problem %s", probName.c_str());
	__testlib_ensuresPreconditions();
	testlibMode = _checker;
	random_t::version = 1; // Random generator version
	__testlib_set_binary(stdin);
	ouf.mode = _output;

	{//Keep alive on broken pipes
		//signal(SIGPIPE, SIG_IGN);
		struct sigaction sa;
		sa.sa_handler = SIG_IGN;
		sigaction(SIGPIPE, &sa, NULL);
	}

	int required_args = 1 + 2 * num_processes;
	if (argc < required_args || required_args+1 < argc) {
		string usage = format("'%s'", argv[0]);
		for (int i = 0; i < num_processes; i++)
			usage += format(" sol%d-to-mgr mgr-to-sol%d", i, i);
		usage += " [mgr_log] < input-file";
		quitf(_fail,
			"Manager for problem %s:\n"
			"Invalid number of arguments: %d\n"
			"Usage: %s",
			probName.c_str(), argc-1, usage.c_str());
	}

	inf.init(stdin, _input);
	closeOnHalt(stdout);
	closeOnHalt(stderr);

	mgr2sol.resize(num_processes);
	sol2mgr.resize(num_processes);
	for (int i = 0; i < num_processes; i++) {
		mgr2sol[i] = openFile(argv[1 + 2*i + 1], "a");
		sol2mgr[i] = openFile(argv[1 + 2*i + 0], "r");
	}

	if (argc > required_args) {
		log_file = openFile(argv[required_args], "w");
	} else {
		log_file = nullptr;
	}
}
/********************************* End testlib-related material *********************************/

// grader/manager protocol

const int secret_g2m = 0x7F6BA410;
const int secret_m2g = 0XCB7489D0;
const int code_mask  = 0x0000000F;

const int M2G_CODE__OK = 0;
const int M2G_CODE__DIE = 1;

const int G2M_CODE__OK = 0;
const int G2M_CODE__PV_CALL_EXIT = 13;
const int G2M_CODE__PV_TAMPER_M2G = 14;
const int G2M_CODE__SILENT = 15;


int fifo_idx = 0;

void out_flush() {
	fflush(mgr2sol[fifo_idx]);
}

void write_int(int x) {
	FILE* fout = mgr2sol[fifo_idx];
	if (1 != fwrite(&x, sizeof(x), 1, fout)) {
		nullifyFile(fifo_idx);
		log_printf("Could not write int to mgr2sol[%d]\n", fifo_idx);
	}
}

void write_int_array(const int* arr, int len) {
	for (int i = 0; i < len; ++i)
		write_int(arr[i]);
	/*FILE* fout = mgr2sol[fifo_idx];
	if (int ret = fwrite(arr, sizeof(int), len, fout); len != ret) {
		nullifyFile(fifo_idx);
		log_printf("Could not write int array of size %d to mgr2sol[%d], fwrite returned %d\n", len, fifo_idx, ret);
	}*/
}

void write_int_vector(const vector<int>& v) {
	write_int_array(v.data(), v.size());
}

void write_secret(int m2g_code = M2G_CODE__OK) {
	write_int(secret_m2g | m2g_code);
}

#ifdef __GNUC__
__attribute__ ((format (printf, 2, 3)))
#endif
NORETURN void die(TResult result, const char* format, ...) {
	FMT_TO_RESULT(format, format, message);
	log_printf("Dying with message '%s'\n", message.c_str());
	for (int i = 0; i < (int)mgr2sol.size(); ++i)
		if(mgr2sol[i] != nullptr) {
			fifo_idx = i;
			log_printf("Sending secret with code DIE to mgr2sol[%d]\n", fifo_idx);
			write_secret(M2G_CODE__DIE);
			out_flush();
		}
	log_printf("Quitting with result code %d\n", int(result));
	quit(result, message);
}

/*NORETURN void die_invalid_argument(const string &msg) {
	RESULT_MESSAGE_WRONG += ": Invalid argument";
	die(_wa, "%s", msg.c_str());
}*/

NORETURN void die_rte(const string &msg) {
	RESULT_MESSAGE_WRONG = "Runtime Error";
	die(_wa, "%s", msg.c_str());
}

int read_int() {
	FILE* fin = sol2mgr[fifo_idx];
	int x;
	if (1 != fread(&x, sizeof(x), 1, fin)) {
		nullifyFile(fifo_idx);
		die_rte("manual RTE, cant read int from grader");
//		die(_fail, "Could not read int from sol2mgr[%d]", fifo_idx);
	}
	return x;
}


void read_secret() {
	int secret = read_int();
	if((secret & ~code_mask) != secret_g2m)
		die(_pv, "Possible tampering with sol2mgr[%d]", fifo_idx);
	int g2m_code = secret & code_mask;
	switch (g2m_code) {
		case G2M_CODE__OK:
			return;
		case G2M_CODE__SILENT:
			die(_fail, "Unexpected g2m_code SILENT from sol2mgr[%d]", fifo_idx);
		case G2M_CODE__PV_TAMPER_M2G:
			die(_pv, "Possible tampering with mgr2sol[%d]", fifo_idx);
		case G2M_CODE__PV_CALL_EXIT:
			die(_pv, "Solution[%d] called exit()", fifo_idx);
		default:
			die(_fail, "Unknown g2m_code %d from sol2mgr[%d]", g2m_code, fifo_idx);
	}
}


struct TestCase {
	int N;
	vector<int> P;
};

TestCase ReadTestCase() {
	int N = inf.readInt();
	vector<int> P(N, 0);
	for (int i = 0; i < N; ++i)
		P[i] = inf.readInt();
	
	fclose(stdin);
	return TestCase{
		.N = N,
		.P = P
	};
}

vector<int> RunAlicia(const TestCase &test) {
	write_secret();
	write_int(test.N);
	for (int i = 0; i < test.N; ++i)
		write_int(test.P[i]);
	//write_int_vector(test.P);
	out_flush();

	read_secret();
	int N = read_int();
	if (N != test.N) {
		die(_wa, "Alicia returned array of wrong size");
	}

	vector<int> Q(N);
	for (int i = 0; i < N; i++) {
		Q[i] = read_int();
	}

	for (int i = 0; i < N; ++i) {
		if (Q[i] == -1)
			continue;
		if (Q[i] != test.P[i])
			die(_wa, "Alicia returned array with invalid entries");
	}

	return Q;
}

vector<int> RunBeatriz(vector<int> Q) {
	write_secret();
	write_int(Q.size());
	write_int_vector(Q);
	out_flush();

	read_secret();
	int N = read_int();
	if (N != (int)Q.size()) {
		die(_wa, "Beatriz returned array of wrong size");
	}

	vector<int> answer(N, 0);
	for (int i = 0; i < N; ++i) {
		answer[i] = read_int();
	}

	return answer;
}

int main(int argc, char **argv) {
	registerManager("magic", 2, argc, argv);

	fifo_idx = 0; // Mode: Encoder
	TestCase test = ReadTestCase();
	vector<int> Q = RunAlicia(test);
	nullifyFile(fifo_idx);

	fifo_idx = 1; // Mode: Decoder
	vector<int> answer = RunBeatriz(Q);
	nullifyFile(fifo_idx);

	int correct = 1, K = 0;

	for (int i = 0; i < test.N; i++) {
		if (answer[i] != test.P[i]) {
			correct = 0;
		}
		if (Q[i] == -1) {
			K++;
		}
	}

	if (!correct) {
		quitf(_wa, "guessed incorrect array");
	}

	if (true) { //no subtask distinction
		if (K == 0)
			quitf(_wa, "correct K = 0");
		else if (K < 16)
			quitp(0.2 + 0.05 * K, "correct K = %d", K);
		else
			quitf(_ok, "correct K = %d", K);
	}

	die(_fail, "Reached an unreachable code!!!");

	return 0;
}
