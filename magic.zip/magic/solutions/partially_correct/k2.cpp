#include <bits/stdc++.h>
#include "magic.h"
using namespace std;

vector<int> Alicia(vector<int> P) {

  int N = P.size();

  int L = 0, R = 3;

  if (P[L] < P[L+1]) {
    P[L] = -1;
    P[L+1] = -1;
  }
  else if (P[L+1] < P[L+2]) {
    P[L+1] = -1;
    P[L+2] = -1;
  }
  else if (P[L+2] < P[L+3]) {
    P[L+2] = -1;
    P[L+3] = -1;
  }
  else {
    P[L] = -1;
    P[L+3] = -1;
  }
  return P;
}


vector<int> Beatriz(vector<int> Q) {

  int N = Q.size();
  int L = 0, R = 3;

  set<int> S;
  for (int i = 1; i <= N; i++) {
    S.insert(i);
  }

  for (int i = 0; i < N; i++) {
    if (Q[i] != -1) {
      S.erase(Q[i]);
    }
  }
  int x = *S.begin(), y = *(++S.begin());

  int a = L, b = R;
  while (Q[a] != -1)
    a++;
  while (Q[b] != -1)
    b--;

  if (b > a + 1)
    swap(x, y);

  Q[a] = x;
  Q[b] = y;

  return Q;
}
