#include <bits/stdc++.h>
#include "magic.h"
using namespace std;

vector<int> Alicia (vector<int> P) {

  int N = P.size();

  int L = 0, R = N-1;

  while (L+3 < R) {

    int pmin = 0;
    for (int i=L; i<=R; i++)
      if(P[i] < P[pmin])
        pmin = i;

    P[pmin] = -1;
    int mid = (L+R)/2;

    if(pmin <= mid)
      L = mid + 1;
    else
      R = mid;

  }

  if (P[L] < P[L+1]) {
    P[L] = -1;
    P[L+1] = -1;
  }
  else if (P[L+1] < P[L+2]) {
    P[L+1] = -1;
    P[L+2] = -1;
  }
  else if (P[L+2] < P[L+3]) {
    P[L+2] = -1;
    P[L+3] = -1;
  }
  else {
    P[L] = -1;
    P[L+3] = -1;
  }
  return P;

}


vector<int> Beatriz (vector<int> Q) {

  int N = Q.size();
  int L = 0, R = N-1;

  set<int> S;
  for (int i=1; i<=N; i++) {
    S.insert(i);
  }

  while (L+3 < R) {

    int mid = (L+R)/2;
    int cL = 0, cR = 0;
    for (int i=L; i<=mid; i++) {
      if(Q[i] == -1)
        cL++;
    }
    for (int i=mid+1; i<=R; i++) {
      if(Q[i] == -1)
        cR++;
    }

    if (cL == 1) {
      for (int i=mid+1; i<=R; i++) {
        if (Q[i] == -1) {
          Q[i] = *S.begin();
        }
        S.erase(Q[i]);
      }
      L = mid + 1;
    }
    else {
      for (int i=L; i<=mid; i++) {
        if (Q[i] == -1) {
          Q[i] = *S.begin();
        }
        S.erase(Q[i]);
      }
      R = mid;
    }
  }

  for (int i=L; i<=R; i++) {
    if (Q[i] != -1) {
      S.erase(Q[i]);
    }
  }
  int x = *S.begin(), y = *(++S.begin());

  int a = L, b = R;
  while (Q[a] != -1)
    a++;
  while (Q[b] != -1)
    b--;

  if(b > a + 1)
    swap(x,y);

  Q[a] = x;
  Q[b] = y;

  return Q;

}