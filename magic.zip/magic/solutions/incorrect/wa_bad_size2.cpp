#include "magic.h"

std::vector<int> Alicia (std::vector<int> P) {
    return P;
}

std::vector<int> Beatriz (std::vector<int> Q) {
    return {1, 2};
}
