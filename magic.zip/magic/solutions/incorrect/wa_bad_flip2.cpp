#include "magic.h"

std :: vector<int> Alicia (std :: vector<int> P) {
    P[0] = 0;
    return P;
}

std :: vector<int> Beatriz (std :: vector<int> Q) {
    Q[0] = (-Q[0])-1;
    return Q;
}
