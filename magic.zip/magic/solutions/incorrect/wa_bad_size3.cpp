#include "magic.h"

std::vector<int> Alicia (std::vector<int> P) {
    std::vector<int> ret;
    ret.pop_back();
    return ret;
}

std::vector<int> Beatriz (std::vector<int> Q) {
    return {1, 2};
}
