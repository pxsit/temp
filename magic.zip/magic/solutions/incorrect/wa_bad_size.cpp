#include "magic.h"

std::vector<int> Alicia (std::vector<int> P) {
    P.pop_back();
    return P;
}

std::vector<int> Beatriz (std::vector<int> Q) {
    return Q;
}
