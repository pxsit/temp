#include "magic.h"

std :: vector<int> Alicia (std :: vector<int> P) {
    std::swap(P[0], P[1]);
    return P;
}

std :: vector<int> Beatriz (std :: vector<int> Q) {
    std::swap(Q[0], Q[1]);
    return Q;
}
