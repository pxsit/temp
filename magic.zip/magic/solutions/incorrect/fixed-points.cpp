#include <bits/stdc++.h>
#include "magic.h"
using namespace std;

vector<int> Alicia (std :: vector<int> P) {

  int N = P.size();
  
  for (int i=0; i<N; i++) {
    if (P[i] == i+1) {
        P[i] = -1;
    }
  }

  return P;
}

vector<int> Beatriz (vector<int> Q) {

  int N = Q.size();

  vector<int> answer (N);

  for (int i=0; i<N; i++) {
    if (Q[i] == -1) {
      answer[i] = i+1;
    }
    else {
      answer[i] = Q[i];
    }
  }

  return answer;
}

