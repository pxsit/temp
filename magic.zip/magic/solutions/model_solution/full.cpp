#include <bits/stdc++.h>
#include "magic.h"
using namespace std;

vector<int> Alicia (vector<int> P) {

  int N = P.size();

  std :: vector<int> dp_lis(N), dp_lds(N);
  std :: vector<int> jmp_lis(N), jmp_lds(N);

  for(int i=N-1;i>=0;i--){
    dp_lis[i] = dp_lds[i] = 1;
    for(int j=i+1;j<N;j++){
      if(P[j] > P[i] && dp_lis[j]+1 > dp_lis[i]){
        dp_lis[i] = dp_lis[j] + 1;
        jmp_lis[i] = j;
      }
      else if(P[j] < P[i] && dp_lds[j]+1 > dp_lds[i]){
        dp_lds[i] = dp_lds[j] + 1;
        jmp_lds[i] = j;
      }
    }
  }

  std :: vector<int> lis, lds;
  
  int id=0;
  for(int i=1; i<N; i++)
    if(dp_lis[i] > dp_lis[id]) 
      id = i;

  while(dp_lis[id] > 1){
    lis.push_back(id);
    id = jmp_lis[id];
  }
  lis.push_back(id);

  id=0;
  for(int i=1; i<N; i++)
    if(dp_lds[i] > dp_lds[id]) 
      id = i;

  while(dp_lds[id] > 1){
    lds.push_back(id);
    id = jmp_lds[id];
  }
  lds.push_back(id);
  
  int sq = 0;
  while(sq*sq < N)
    sq++;

  if(lis.size() >= sq) {
    for(int i=0; i<sq; i++)
      P[lis[i]] = -1;
  }
  else {
    for(int i=0;i<sq+1;i++) {
      P[lds[i]] = -1;
    }
  }

  return P;

}


vector<int> Beatriz (vector<int> Q) {

  int N = Q.size();

  set<int> S;
  for(int q : Q) {
    S.insert(q);
  }

  std :: vector<int> miss;
  for(int i=1; i<=N; i++) {
    if(S.find(i) == S.end())
      miss.push_back(i);
  }

  if(miss.size()%2 == 1) {
    reverse(miss.begin(), miss.end());
  }

  int pos = 0;
  for(int &q : Q)
    if(q == -1){
      q = miss[pos];
      pos++;
    }

  return Q;

}