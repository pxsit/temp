#include <vector>

std::vector<std::vector<int>> create_map(int N, int M, std::vector<int> A, std::vector<int> B);
